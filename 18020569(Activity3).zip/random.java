//Q2-(18020569)

import java.util.*;

public class random {

    public static void main(String[] args) {
       Random rNum=new Random();
	for (int i = 0; i < 5; i++){
		int rand;
		rand=rNum.nextInt(100);
                     if(rand>=50){
                         System.out.println(rand+" : High");
                     }else{
                         System.out.println(rand+" : Low");
                      }
		}
     }
}

