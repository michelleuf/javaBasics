//Q1-(Index No : 18020569)

import java.util.Scanner;

public class Calculator {

    public static void main(String[] args) {
       Scanner input=new Scanner(System.in);
        System.out.println("Enter first number : ");
        float first=input.nextFloat();
        System.out.println("Enter second number : ");
        float second=input.nextFloat();
        System.out.println("Enter operator : ");
        String op;
        op = input.next();
       
        switch(op){
        
        case "+" :
            System.out.println(first+" + "+second+" = "+(first+second));
            break;
        case "-" :
            System.out.println(first+" - "+second+" = "+(first-second));
            break;
        case "*" :
            System.out.println(first+" * "+second+" = "+(first*second));
            break;
        case "/" :
            System.out.println(first+" / "+second+" = "+(first/second));
            break;
	default:
            System.out.println("Incorrect Operator");
         
        }
       
     }
}

